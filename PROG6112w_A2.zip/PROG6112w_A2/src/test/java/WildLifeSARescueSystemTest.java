/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */


/**
 *
 * @author theodorav
 */

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RescueSystemTest {
    private RescueManager manager;
    private InjuredAnimalRescue injured;
    private OrphanedAnimalRescue orphan;
    private EndangeredSpeciesRescue endangered;

    @BeforeEach
    void setUp() {
        manager = new RescueManager();

        // 5 days x R500 = 2500 base
        injured = new InjuredAnimalRescue("R001", "Leo", "Lion", "Kruger", "Thabo", 5, 500,
                "Broken leg", 3000, true);

        orphan = new OrphanedAnimalRescue("R002", "Pip", "Rhino", "Limpopo", "Sipho", 4, 300,
                2, 800, true);

        endangered = new EndangeredSpeciesRescue("R003", "Ari", "Pangolin", "Mpumalanga", "Naledi", 10, 400,
                "Critically Endangered", 6000, true);
    }

    // ----- cost calculations -----
    @Test
    void injuredCostIncludesVetAndSurgery() {
        assertEquals(2500 + 3000 + 5000, injured.calculateTotalCost(), 0.001);
    }

    @Test
    void injuredCostWithoutSurgery() {
        RescueCase c = new InjuredAnimalRescue("R010", "", "Kudu", "X", "Y", 2, 100, "Cut", 1000, false);
        assertEquals(200 + 1000, c.calculateTotalCost(), 0.001);
    }

    @Test
    void orphanedCostIncludesFeedingAndFoster() {
        assertEquals(1200 + 800 + 2500, orphan.calculateTotalCost(), 0.001);
    }

    @Test
    void endangeredCostIncludesSecurityAndSpecialistTeam() {
        assertEquals(4000 + 6000 + 8000, endangered.calculateTotalCost(), 0.001);
    }

    // ----- priority calculations -----
    @Test
    void injuredPriorityRules() {
        assertEquals(RescuePriority.CRITICAL, injured.determinePriority());
        assertEquals(RescuePriority.HIGH,
                new InjuredAnimalRescue("A", "", "S", "L", "R", 1, 1, "I", 12000, false).determinePriority());
        assertEquals(RescuePriority.MEDIUM,
                new InjuredAnimalRescue("B", "", "S", "L", "R", 1, 1, "I", 500, false).determinePriority());
    }

    @Test
    void orphanedPriorityRules() {
        assertEquals(RescuePriority.HIGH, orphan.determinePriority());
        assertEquals(RescuePriority.MEDIUM,
                new OrphanedAnimalRescue("C", "", "S", "L", "R", 1, 1, 8, 1, false).determinePriority());
        assertEquals(RescuePriority.LOW,
                new OrphanedAnimalRescue("D", "", "S", "L", "R", 1, 1, 24, 1, false).determinePriority());
    }

    @Test
    void endangeredPriorityRules() {
        assertEquals(RescuePriority.CRITICAL, endangered.determinePriority());
        assertEquals(RescuePriority.HIGH,
                new EndangeredSpeciesRescue("E", "", "S", "L", "R", 1, 1, "Vulnerable", 1, false).determinePriority());
    }

    // ----- status updates -----
    @Test
    void newCaseStartsAsReported() {
        assertEquals(RescueStatus.REPORTED, injured.getStatus());
    }

    @Test
    void startAndCompleteUpdatesStatus() {
        injured.startRescue();
        assertEquals(RescueStatus.IN_PROGRESS, injured.getStatus());
        injured.completeRescue();
        assertEquals(RescueStatus.COMPLETED, injured.getStatus());
    }

    @Test
    void cannotCompleteBeforeStarting() {
        assertThrows(IllegalStateException.class, () -> injured.completeRescue());
    }

    @Test
    void managerUpdateStatus() {
        manager.addCase(orphan);
        assertTrue(manager.updateStatus("R002", RescueStatus.COMPLETED));
        assertEquals(RescueStatus.COMPLETED, orphan.getStatus());
        assertFalse(manager.updateStatus("NOPE", RescueStatus.COMPLETED));
    }

    // ----- searching -----
    @Test
    void findsExistingCase() {
        manager.addCase(injured);
        manager.addCase(orphan);
        assertSame(orphan, manager.findById("R002"));
        assertSame(orphan, manager.findById("r002"));
    }

    @Test
    void returnsNullForMissingCase() {
        manager.addCase(injured);
        assertNull(manager.findById("R999"));
    }

    // ----- duplicate IDs -----
    @Test
    void duplicateIdsRejected() {
        manager.addCase(injured);
        RescueCase dup = new OrphanedAnimalRescue("R001", "Dup", "Zebra", "X", "Y", 1, 1, 5, 1, false);
        assertThrows(IllegalArgumentException.class, () -> manager.addCase(dup));
        assertEquals(1, manager.getCaseCount());
    }

    // ----- validation + reporting -----
    @Test
    void invalidDataIsRejected() {
        assertThrows(IllegalArgumentException.class,
                () -> new InjuredAnimalRescue("", "", "Lion", "L", "R", 1, 1, "I", 1, false));
        assertThrows(IllegalArgumentException.class,
                () -> new InjuredAnimalRescue("X", "", "Lion", "L", "R", 0, 1, "I", 1, false));
    }

    @Test
    void totalEstimatedCostSumsAllCases() {
        manager.addCase(injured);
        manager.addCase(orphan);
        manager.addCase(endangered);
        assertEquals(10500 + 4500 + 18000, manager.getTotalEstimatedCost(), 0.001);
        assertTrue(manager.generateReport().contains("Total Rescue Cases        : 3"));
    }
}